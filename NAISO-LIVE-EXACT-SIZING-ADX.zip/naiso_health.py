"""Watchdog, heartbeat registry and bounded restart policy for NAISO-LIVE.

The watchdog never kills a thread and never restarts a critical engine while a
safety gate is unresolved.  It detects stalled/hung engines, records their
stacks for diagnosis, alerts once per incident, and asks the caller-supplied
restart callback to act within a bounded exponential-backoff budget.
"""
from __future__ import annotations

import inspect
import random
import sys
import threading
import time
import traceback
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional


@dataclass
class RestartRecord:
    name: str
    reason: str
    ts: float
    attempt: int
    delay: float
    result: str = "PENDING"
    detail: str = ""


class RestartPolicy:
    """Strictly bounded restart attempts with exponential backoff and jitter."""

    MAX_RECORDS_PER_COMPONENT = 200

    def __init__(
        self,
        *,
        max_attempts: int = 3,
        window_sec: float = 300.0,
        base_delay_sec: float = 2.0,
        max_delay_sec: float = 60.0,
        jitter_fraction: float = 0.20,
        seed: Optional[int] = None,
        monotonic_fn=None,
        sleep_fn=None,
    ) -> None:
        self.max_attempts = max(1, int(max_attempts))
        self.window_sec = max(1.0, float(window_sec))
        self.base_delay_sec = max(0.1, float(base_delay_sec))
        self.max_delay_sec = max(self.base_delay_sec, float(max_delay_sec))
        self.jitter_fraction = min(0.5, max(0.0, float(jitter_fraction)))
        self._rng = random.Random(seed)
        self._monotonic = monotonic_fn or time.monotonic
        self._sleep = sleep_fn or time.sleep
        self._records: Dict[str, List[RestartRecord]] = {}
        self._lock = threading.RLock()

    def next_delay(self, name: str) -> Optional[float]:
        """Return the next bounded delay, or None when the budget is exhausted."""
        now = float(self._monotonic())
        with self._lock:
            records = self._records.setdefault(str(name), [])
            recent = [r for r in records if r.result != "PENDING" and now - r.ts <= self.window_sec]
            if len(recent) >= self.max_attempts:
                return None
            attempt = len(recent)
            base = min(self.base_delay_sec * (2 ** attempt), self.max_delay_sec)
            return max(0.05, base + base * self.jitter_fraction * self._rng.uniform(-1.0, 1.0))

    def begin(self, name: str, reason: str, delay: float) -> RestartRecord:
        record = RestartRecord(str(name), str(reason), float(self._monotonic()),
                               len(self._records.get(str(name), [])) + 1, float(delay))
        with self._lock:
            records = self._records.setdefault(str(name), [])
            records.append(record)
            # Restart history is diagnostic, not an audit ledger. Cap it so a
            # long-running process cannot grow memory without bound; the active
            # attempt budget is computed from the recent window only.
            if len(records) > self.MAX_RECORDS_PER_COMPONENT:
                del records[:len(records) - self.MAX_RECORDS_PER_COMPONENT]
        return record

    def finish(self, record: RestartRecord, result: str, detail: str = "") -> RestartRecord:
        with self._lock:
            record.result = str(result)
            record.detail = str(detail)[:300]
        return record

    def records(self, name: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
        with self._lock:
            selected = self._records.items() if name is None else [(str(name), self._records.get(str(name), []))]
            rows = [r for _, values in selected for r in values]
        rows.sort(key=lambda r: r.ts, reverse=True)
        return [{
            "name": r.name, "reason": r.reason, "ts": r.ts, "attempt": r.attempt,
            "delay": round(r.delay, 3), "result": r.result, "detail": r.detail,
        } for r in rows[:max(1, int(limit))]]

    def reset(self, name: str) -> None:
        with self._lock:
            self._records.pop(str(name), None)


@dataclass
class ComponentHealth:
    name: str
    interval_sec: float
    grace_sec: float
    critical: bool = True
    restartable: bool = False
    last_beat: float = 0.0
    has_beat: bool = False
    last_restart: float = 0.0
    status: str = "UNKNOWN"
    diagnostics: Dict[str, Any] = field(default_factory=dict)
    recovery_verifier: Optional[Callable[[], tuple]] = None
    lifecycle: str = "RUNNING"
    last_progress: float = 0.0
    idle_until: float = 0.0
    blocked_until: float = 0.0
    reason: str = ""
    thread_name: str = ""
    cycle_id: int = 0
    resume_requires_liveness: bool = False


class HealthWatchdog:
    """Heartbeat-based liveness monitor with safe, bounded recovery callbacks."""

    def __init__(
        self,
        *,
        restart_policy: Optional[RestartPolicy] = None,
        alert_fn: Optional[Callable[[str, str], None]] = None,
        safety_gate: Optional[Callable[[], (bool, str)]] = None,
        check_interval_sec: float = 2.0,
        monotonic_fn=None,
        sleep_fn=None,
    ) -> None:
        self.restart_policy = restart_policy or RestartPolicy()
        self.alert_fn = alert_fn
        self.safety_gate = safety_gate
        self.check_interval_sec = max(0.2, float(check_interval_sec))
        self._monotonic = monotonic_fn or time.monotonic
        self._sleep = sleep_fn or time.sleep
        self._components: Dict[str, ComponentHealth] = {}
        self._restart_callbacks: Dict[str, Callable[[], bool]] = {}
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._alarms: Dict[str, str] = {}

    def monotonic(self) -> float:
        """Expose the injected clock so callers can schedule real deadlines."""
        return float(self._monotonic())

    def register(
        self,
        name: str,
        *,
        interval_sec: float,
        grace_sec: Optional[float] = None,
        critical: bool = True,
        restartable: bool = False,
        restart_fn: Optional[Callable[[], bool]] = None,
        recovery_verifier: Optional[Callable[[], tuple]] = None,
        lifecycle: str = "RUNNING",
        refresh: bool = True,
        resume_requires_liveness: bool = False,
    ) -> None:
        key = str(name)
        grace = float(grace_sec if grace_sec is not None else max(3.0, float(interval_sec) * 2.0))
        with self._lock:
            component = self._components.get(key)
            if component is None:
                component = ComponentHealth(key, float(interval_sec), grace, bool(critical), bool(restartable))
                self._components[key] = component
            else:
                component.interval_sec = float(interval_sec)
                component.grace_sec = grace
                component.critical = bool(critical)
                component.restartable = bool(restartable)
            component.recovery_verifier = recovery_verifier
            component.resume_requires_liveness = bool(resume_requires_liveness)
            if refresh:
                now = float(self._monotonic())
                component.last_beat = now
                component.last_progress = now
                component.has_beat = True
                component.status = "HEALTHY"
                component.lifecycle = str(lifecycle or "RUNNING")
                component.idle_until = 0.0
                component.blocked_until = 0.0
                component.reason = ""
            elif component.last_progress <= 0:
                component.last_progress = float(self._monotonic())
            if restart_fn is not None:
                self._restart_callbacks[key] = restart_fn

    def beat(self, name: str, **diagnostics: Any) -> None:
        """Record a real progress point plus optional lifecycle metadata.

        ``state`` is one of RUNNING/IDLE/BLOCKED/FAILED. ``idle_until`` and
        ``blocked_until`` are absolute monotonic deadlines. ``progress=False``
        records a status-only observation without advancing last_progress.
        """
        with self._lock:
            component = self._components.get(str(name))
            if component is None:
                self.register(name, interval_sec=self.check_interval_sec)
                component = self._components[str(name)]
            now = float(self._monotonic())
            is_progress = diagnostics.pop("progress", True) is not False
            if is_progress:
                component.last_beat = now
                component.last_progress = now
                component.has_beat = True
                # Dedupe within one incident, not forever. Real progress after a
                # stall/recovery re-arms the same component for a future event.
                if component.status in {"STALLED", "STALLED_SAFE_HOLD", "RECOVERED",
                                        "RESTART_FAILED", "FAILED", "RECOVERY_DEFERRED",
                                        "IDLE_SAFE_HOLD"}:
                    for alarm_key in (f"stalled:{component.name}", f"failed:{component.name}",
                                      f"recovery_deferred:{component.name}",
                                      f"restart_failed:{component.name}",
                                      f"schedule_blocked:{component.name}",
                                      f"schedule_failed:{component.name}"):
                        self._alarms.pop(alarm_key, None)
            state = diagnostics.pop("state", None)
            if state is not None and str(state).upper() in {"RUNNING", "IDLE", "BLOCKED", "FAILED"}:
                component.lifecycle = str(state).upper()
                if component.lifecycle == "RUNNING":
                    component.idle_until = 0.0
                    component.blocked_until = 0.0
            reason = diagnostics.pop("reason", None)
            if reason is not None:
                component.reason = str(reason)[:200]
            idle_until = diagnostics.pop("idle_until", None)
            if idle_until is not None:
                component.idle_until = float(idle_until)
            blocked_until = diagnostics.pop("blocked_until", None)
            if blocked_until is not None:
                component.blocked_until = float(blocked_until)
            phase = diagnostics.pop("phase", None)
            if phase is not None:
                diagnostics["last_phase"] = phase
            thread_name = diagnostics.pop("thread_name", None)
            if thread_name is not None:
                component.thread_name = str(thread_name)[:120]
            cycle_id = diagnostics.pop("cycle_id", None)
            if cycle_id is not None:
                try:
                    component.cycle_id = int(cycle_id)
                except (TypeError, ValueError):
                    pass
            if component.lifecycle == "FAILED":
                component.status = "FAILED"
            elif is_progress:
                component.status = "HEALTHY"
            if diagnostics:
                component.diagnostics.update({k: str(v)[:120] for k, v in diagnostics.items()})

    def start(self) -> bool:
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return False
            self._stop.clear()
            self._thread = threading.Thread(target=self._run, name="naiso-health-watchdog", daemon=True)
            self._thread.start()
            return True

    def stop(self, timeout: float = 5.0) -> None:
        self._stop.set()
        thread = self._thread
        if thread is not None and thread.is_alive():
            thread.join(timeout=max(0.1, float(timeout)))

    def _run(self) -> None:
        while not self._stop.wait(self.check_interval_sec):
            try:
                self.check()
            except Exception as exc:
                self._alert("watchdog_error", "ERROR", f"{type(exc).__name__}: {exc}")

    def _alert(self, key: str, level: str, message: str) -> None:
        """Alert once per event key, even when the message embeds a changing age.

        Stall messages include an age that grows on every watchdog tick. Comparing
        the full message caused the same stall to alert repeatedly and spam the
        operator channel without representing a new event.
        """
        with self._lock:
            if key in self._alarms:
                return
            self._alarms[key] = message
        if callable(self.alert_fn):
            try:
                self.alert_fn(message, level)
            except Exception:
                pass

    def _stack_snapshot(self, component: ComponentHealth) -> Dict[str, Any]:
        stacks: Dict[str, str] = {}
        try:
            short_name = component.name.split(":", 1)[-1]
            for thread_id, frame in sys._current_frames().items():
                name = threading._active.get(thread_id)
                if name is None:
                    continue
                matches_component = (component.name in name.name or short_name in name.name)
                matches_foreground = (component.name == "main_loop" and name.name == "MainThread")
                if not matches_component and not matches_foreground:
                    continue
                stacks[str(thread_id)] = "".join(traceback.format_stack(frame))[-2000:]
        except Exception as exc:
            stacks["error"] = f"{type(exc).__name__}: {exc}"
        return {"possible_stacks": stacks}

    @staticmethod
    def _invoke_restart(callback: Callable, context: Dict[str, Any]) -> bool:
        """Pass verification context only to callbacks that accept it."""
        try:
            signature = inspect.signature(callback)
            params = signature.parameters
            accepts_context = ("context" in params or
                               any(p.kind is inspect.Parameter.VAR_KEYWORD for p in params.values()))
        except (TypeError, ValueError):
            accepts_context = False
        return bool(callback(context) if accepts_context else callback())

    def check(self) -> Dict[str, Any]:
        now = float(self._monotonic())
        report: Dict[str, Any] = {}
        with self._lock:
            components = list(self._components.values())
        for component in components:
            lifecycle = component.lifecycle or "RUNNING"
            progress_at = max(component.last_beat, component.last_progress or 0.0)
            base_age = max(0.0, now - progress_at)
            scheduled_due = None
            if lifecycle == "IDLE":
                scheduled_due = component.idle_until or (progress_at + component.interval_sec)
                if now < scheduled_due:
                    component.status = "IDLE"
                    report[component.name] = {
                        "status": "IDLE", "lifecycle": "IDLE", "age_sec": round(base_age, 3),
                        "next_due_sec": round(max(0.0, scheduled_due - now), 3),
                        "reason": component.reason,
                    }
                    continue
            elif lifecycle == "BLOCKED":
                scheduled_due = component.blocked_until or (progress_at + component.grace_sec)
                if now < scheduled_due:
                    component.status = "BLOCKED"
                    report[component.name] = {
                        "status": "BLOCKED", "lifecycle": "BLOCKED", "age_sec": round(base_age, 3),
                        "next_due_sec": round(max(0.0, scheduled_due - now), 3),
                        "reason": component.reason,
                    }
                    continue
            if lifecycle == "IDLE" and scheduled_due is not None and now >= scheduled_due:
                # A scheduled worker is allowed to wake exactly when due. This is
                # not a stall/restart: it must not consume the restart budget or
                # emit a false STALLED alert after a healthy 20-minute sleep.
                verification_context: Dict[str, Any] = {}
                verified = True
                verify_reason = "SCHEDULED_DUE"
                if callable(component.recovery_verifier):
                    try:
                        verified, verify_reason, raw_context = component.recovery_verifier()
                        verification_context = dict(raw_context or {})
                    except Exception as exc:
                        verified, verify_reason = False, f"VERIFIER_EXCEPTION:{type(exc).__name__}"
                if not verified:
                    component.status = "IDLE_SAFE_HOLD"
                    component.idle_until = now + min(60.0, component.interval_sec * 0.25)
                    self._alert(f"schedule_blocked:{component.name}", "WARN",
                                f"[WATCHDOG] scheduled restart of {component.name} deferred: {verify_reason}")
                    report[component.name] = {"status": component.status, "lifecycle": "IDLE",
                                              "age_sec": round(now - scheduled_due, 3),
                                              "restart": "VERIFICATION_HOLD", "reason": str(verify_reason)}
                    continue
                if callable(self.safety_gate):
                    allowed, reason = self.safety_gate()
                    if not allowed and not (
                        verification_context.get("flat_verified") and
                        str(reason) in {"OPEN_POSITION", "OPEN_POSITION_VERIFIED"}
                    ):
                        component.status = "IDLE_SAFE_HOLD"
                        component.idle_until = now + min(60.0, component.interval_sec * 0.25)
                        self._alert(f"schedule_blocked:{component.name}", "WARN",
                                    f"[WATCHDOG] scheduled restart of {component.name} deferred: {reason}")
                        report[component.name] = {"status": component.status, "lifecycle": "IDLE",
                                                  "age_sec": round(now - scheduled_due, 3),
                                                  "restart": "SAFETY_GATE", "reason": str(reason)}
                        continue
                callback = self._restart_callbacks.get(component.name)
                restarted = False
                if callable(callback):
                    try:
                        restarted = self._invoke_restart(callback, verification_context)
                    except Exception as exc:
                        self._alert(f"schedule_failed:{component.name}", "ERROR",
                                    f"[WATCHDOG] scheduled restart of {component.name} failed: "
                                    f"{type(exc).__name__}: {exc}")
                    if restarted:
                        # The dispatched cycle is now the liveness source. Leave
                        # IDLE, clear the stale wake deadline and let the new
                        # cycle's beats govern the next check; otherwise every
                        # subsequent tick would try to start another cycle.
                        component.lifecycle = "RUNNING"
                        component.idle_until = 0.0
                        component.last_beat = now
                        component.last_progress = now
                        component.has_beat = True
                        component.status = "RECOVERED"
                        report[component.name] = {"status": component.status, "lifecycle": "RUNNING",
                                                  "age_sec": round(now - scheduled_due, 3),
                                                  "restart": "SCHEDULED"}
                        continue
                component.status = "IDLE_SAFE_HOLD"
                component.idle_until = now + min(60.0, component.interval_sec * 0.25)
                self._alert(f"schedule_failed:{component.name}", "ERROR",
                            f"[WATCHDOG] scheduled restart of {component.name} unavailable")
                report[component.name] = {"status": component.status, "lifecycle": "IDLE",
                                          "age_sec": round(now - scheduled_due, 3),
                                          "restart": "SCHEDULE_UNAVAILABLE"}
                continue
            age = max(0.0, now - scheduled_due) if scheduled_due is not None else base_age
            # RUNNING progress and scheduled due dates are judged against grace,
            # not against a 20-minute scheduling interval. Using the larger
            # interval here hid genuine in-cycle stalls for scheduled workers.
            stall_window = component.grace_sec
            stalled = component.has_beat and age > stall_window
            if not stalled:
                component.status = "FAILED" if lifecycle == "FAILED" else "HEALTHY"
                report[component.name] = {"status": component.status, "lifecycle": lifecycle,
                                          "age_sec": round(age, 3), "reason": component.reason}
                continue
            component.status = "FAILED" if lifecycle == "FAILED" else "STALLED"
            diagnostics = self._stack_snapshot(component)
            component.diagnostics.update(diagnostics)
            if lifecycle == "FAILED":
                self._alert(f"failed:{component.name}", "ERROR",
                            f"[WATCHDOG] {component.name} failed: {component.reason or 'unknown error'}")
            else:
                self._alert(f"stalled:{component.name}", "CRITICAL",
                            f"[WATCHDOG] {component.name} stalled for {age:.1f}s (critical={component.critical})")
            if not component.restartable or component.name not in self._restart_callbacks:
                report[component.name] = {"status": component.status, "lifecycle": lifecycle,
                                          "age_sec": round(age, 3), "restart": "NOT_RESTARTABLE",
                                          "reason": component.reason}
                continue
            verification_context: Dict[str, Any] = {}
            verified_open_resume = False
            non_trading_resume = False
            if callable(component.recovery_verifier):
                try:
                    verified, verify_reason, context = component.recovery_verifier()
                    verification_context = dict(context or {})
                except Exception as exc:
                    verified, verify_reason, verification_context = False, f"VERIFIER_EXCEPTION:{type(exc).__name__}", {}
                if not verified:
                    component.status = "STALLED_SAFE_HOLD"
                    component.diagnostics["last_verification"] = str(verify_reason)[:120]
                    self._alert(f"verify_blocked:{component.name}", "WARN",
                                f"[WATCHDOG] restart of {component.name} deferred by verification: {verify_reason}")
                    report[component.name] = {"status": component.status, "age_sec": round(age, 3),
                                              "restart": "VERIFICATION_HOLD", "reason": str(verify_reason)}
                    continue
                verified_open_resume = bool(verification_context.get("open_position_verified"))
                non_trading_resume = bool(verification_context.get("non_trading_engine"))
            if callable(self.safety_gate):
                allowed, reason = self.safety_gate()
                if not allowed and not (
                    verified_open_resume and str(reason) in {"OPEN_POSITION", "OPEN_POSITION_VERIFIED"}
                ) and not (
                    non_trading_resume and str(reason) in {"OPEN_POSITION", "OPEN_POSITION_VERIFIED"}
                ):
                    component.status = "STALLED_SAFE_HOLD"
                    self._alert(f"restart_blocked:{component.name}", "WARN",
                                f"[WATCHDOG] restart of {component.name} deferred: {reason}")
                    report[component.name] = {"status": component.status, "age_sec": round(age, 3),
                                              "restart": "SAFETY_GATE", "reason": str(reason)}
                    continue
            delay = self.restart_policy.next_delay(component.name)
            if delay is None:
                component.status = "RESTART_BUDGET_EXHAUSTED"
                self._alert(f"budget:{component.name}", "CRITICAL",
                            f"[WATCHDOG] restart budget exhausted for {component.name}")
                report[component.name] = {"status": component.status, "age_sec": round(age, 3),
                                          "restart": "BUDGET_EXHAUSTED"}
                continue
            self._sleep(delay)
            record = self.restart_policy.begin(component.name, f"stalled_{age:.1f}s", delay)
            callback = self._restart_callbacks[component.name]
            try:
                restarted = self._invoke_restart(callback, verification_context)
                result = "RESTARTED" if restarted else "RESTART_FAILED"
                detail = ""
            except Exception as exc:
                restarted = False
                result = "RESTART_EXCEPTION"
                detail = f"{type(exc).__name__}: {exc}"
            liveness_confirmed = (
                bool(verification_context.get("engine_resumed"))
                if component.resume_requires_liveness else True)
            if restarted and not liveness_confirmed:
                # Foreground engines such as main_loop cannot be replaced by an
                # extra thread. Recovery work may have completed, but the loop
                # itself has not proved liveness; never refresh its heartbeat.
                restarted = False
                result = "RECOVERY_DEFERRED"
                detail = "engine liveness not confirmed; no duplicate thread started"
            self.restart_policy.finish(record, result, detail)
            component.last_restart = float(self._monotonic())
            if restarted:
                component.last_beat = float(self._monotonic())
                component.status = "RECOVERED"
                self._alert(f"recovered:{component.name}", "SUCCESS",
                            f"[WATCHDOG] {component.name} restarted after {age:.1f}s stall")
            elif result == "RECOVERY_DEFERRED":
                component.status = "STALLED_SAFE_HOLD"
                self._alert(f"recovery_deferred:{component.name}", "WARN",
                            f"[WATCHDOG] {component.name} recovery deferred: {detail}")
            else:
                component.status = "RESTART_FAILED"
                self._alert(f"restart_failed:{component.name}", "CRITICAL",
                            f"[WATCHDOG] {component.name} restart failed: {result} {detail}")
            report[component.name] = {"status": component.status, "age_sec": round(age, 3),
                                      "restart": result, "attempt": record.attempt}
        return report

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            now = float(self._monotonic())
            rows = {}
            for name, component in sorted(self._components.items()):
                progress_at = max(component.last_beat, component.last_progress or 0.0)
                rows[name] = {
                    "status": component.status,
                    "lifecycle": component.lifecycle,
                    "critical": component.critical,
                    "restartable": component.restartable,
                    "age_sec": round(max(0.0, now - progress_at), 3),
                    "reason": component.reason,
                    "thread_name": component.thread_name,
                    "cycle_id": component.cycle_id,
                    "next_due_sec": (round(max(0.0, (component.idle_until or component.blocked_until) - now), 3)
                                     if (component.idle_until or component.blocked_until) else None),
                    "last_restart_age_sec": (round(max(0.0, now - component.last_restart), 3)
                                             if component.last_restart else None),
                    "diagnostics": dict(component.diagnostics),
                }
            return {
                "running": bool(self._thread is not None and self._thread.is_alive()),
                "components": rows,
                "restart_history": self.restart_policy.records(limit=30),
                "alerts": dict(self._alarms),
            }
